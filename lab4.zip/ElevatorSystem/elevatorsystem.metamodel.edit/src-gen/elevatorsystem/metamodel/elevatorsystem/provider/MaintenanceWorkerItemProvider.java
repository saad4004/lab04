/**
 */
package elevatorsystem.metamodel.elevatorsystem.provider;

import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;

import elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker;
import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class MaintenanceWorkerItemProvider extends PeopleItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MaintenanceWorkerItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addUserPropertyDescriptor(object);
			addEmployeeIdPropertyDescriptor(object);
			addPhoneNumberPropertyDescriptor(object);
			addTechnicalSkillsPropertyDescriptor(object);
			addWorkerPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the User feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addUserPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_MaintenanceWorker_user_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_MaintenanceWorker_user_feature",
								"_UI_MaintenanceWorker_type"),
						ElevatorsystemPackage.Literals.MAINTENANCE_WORKER__USER, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Employee Id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEmployeeIdPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_MaintenanceWorker_employeeId_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_MaintenanceWorker_employeeId_feature",
						"_UI_MaintenanceWorker_type"),
				ElevatorsystemPackage.Literals.MAINTENANCE_WORKER__EMPLOYEE_ID, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Phone Number feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPhoneNumberPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_MaintenanceWorker_phoneNumber_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_MaintenanceWorker_phoneNumber_feature",
						"_UI_MaintenanceWorker_type"),
				ElevatorsystemPackage.Literals.MAINTENANCE_WORKER__PHONE_NUMBER, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Technical Skills feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTechnicalSkillsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_MaintenanceWorker_technicalSkills_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_MaintenanceWorker_technicalSkills_feature",
								"_UI_MaintenanceWorker_type"),
						ElevatorsystemPackage.Literals.MAINTENANCE_WORKER__TECHNICAL_SKILLS, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Worker feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWorkerPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_MaintenanceWorker_worker_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_MaintenanceWorker_worker_feature",
						"_UI_MaintenanceWorker_type"),
				ElevatorsystemPackage.Literals.MAINTENANCE_WORKER__WORKER, true, false, true, null, null, null));
	}

	/**
	 * This returns MaintenanceWorker.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/MaintenanceWorker"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((MaintenanceWorker) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_MaintenanceWorker_type")
				: getString("_UI_MaintenanceWorker_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(MaintenanceWorker.class)) {
		case ElevatorsystemPackage.MAINTENANCE_WORKER__EMPLOYEE_ID:
		case ElevatorsystemPackage.MAINTENANCE_WORKER__PHONE_NUMBER:
		case ElevatorsystemPackage.MAINTENANCE_WORKER__TECHNICAL_SKILLS:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
