/**
 */
package elevatorsystem.metamodel.elevatorsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Deliver Person</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getUser <em>User</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getEmployeeId <em>Employee Id</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPackages <em>Packages</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getWorkMomentarly <em>Work Momentarly</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getDeliverPerson()
 * @model
 * @generated
 */
public interface DeliverPerson extends People {
	/**
	 * Returns the value of the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User</em>' reference.
	 * @see #setUser(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getDeliverPerson_User()
	 * @model
	 * @generated
	 */
	ElevatorDispatch getUser();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getUser <em>User</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User</em>' reference.
	 * @see #getUser()
	 * @generated
	 */
	void setUser(ElevatorDispatch value);

	/**
	 * Returns the value of the '<em><b>Employee Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Employee Id</em>' attribute.
	 * @see #setEmployeeId(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getDeliverPerson_EmployeeId()
	 * @model
	 * @generated
	 */
	String getEmployeeId();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getEmployeeId <em>Employee Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Employee Id</em>' attribute.
	 * @see #getEmployeeId()
	 * @generated
	 */
	void setEmployeeId(String value);

	/**
	 * Returns the value of the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone Number</em>' attribute.
	 * @see #setPhoneNumber(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getDeliverPerson_PhoneNumber()
	 * @model
	 * @generated
	 */
	String getPhoneNumber();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPhoneNumber <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Phone Number</em>' attribute.
	 * @see #getPhoneNumber()
	 * @generated
	 */
	void setPhoneNumber(String value);

	/**
	 * Returns the value of the '<em><b>Packages</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Packages</em>' attribute.
	 * @see #setPackages(int)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getDeliverPerson_Packages()
	 * @model
	 * @generated
	 */
	int getPackages();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPackages <em>Packages</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Packages</em>' attribute.
	 * @see #getPackages()
	 * @generated
	 */
	void setPackages(int value);

	/**
	 * Returns the value of the '<em><b>Work Momentarly</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Work Momentarly</em>' reference.
	 * @see #setWorkMomentarly(People)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getDeliverPerson_WorkMomentarly()
	 * @model derived="true"
	 * @generated
	 */
	People getWorkMomentarly();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getWorkMomentarly <em>Work Momentarly</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Work Momentarly</em>' reference.
	 * @see #getWorkMomentarly()
	 * @generated
	 */
	void setWorkMomentarly(People value);

} // DeliverPerson
