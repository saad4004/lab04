/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Building Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring <em>Elevatormonitoring</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getName <em>Name</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getEmployeeId <em>Employee Id</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#isManagerPermission <em>Manager Permission</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager()
 * @model
 * @generated
 */
public interface BuildingManager extends EObject {
	/**
	 * Returns the value of the '<em><b>Elevatormonitoring</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevatormonitoring</em>' reference.
	 * @see #setElevatormonitoring(ElevatorMonitoring)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager_Elevatormonitoring()
	 * @model
	 * @generated
	 */
	ElevatorMonitoring getElevatormonitoring();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring <em>Elevatormonitoring</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Elevatormonitoring</em>' reference.
	 * @see #getElevatormonitoring()
	 * @generated
	 */
	void setElevatormonitoring(ElevatorMonitoring value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Employee Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Employee Id</em>' attribute.
	 * @see #setEmployeeId(int)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager_EmployeeId()
	 * @model
	 * @generated
	 */
	int getEmployeeId();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getEmployeeId <em>Employee Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Employee Id</em>' attribute.
	 * @see #getEmployeeId()
	 * @generated
	 */
	void setEmployeeId(int value);

	/**
	 * Returns the value of the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone Number</em>' attribute.
	 * @see #setPhoneNumber(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager_PhoneNumber()
	 * @model
	 * @generated
	 */
	String getPhoneNumber();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getPhoneNumber <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Phone Number</em>' attribute.
	 * @see #getPhoneNumber()
	 * @generated
	 */
	void setPhoneNumber(String value);

	/**
	 * Returns the value of the '<em><b>Manager Permission</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manager Permission</em>' attribute.
	 * @see #setManagerPermission(boolean)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager_ManagerPermission()
	 * @model
	 * @generated
	 */
	boolean isManagerPermission();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#isManagerPermission <em>Manager Permission</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manager Permission</em>' attribute.
	 * @see #isManagerPermission()
	 * @generated
	 */
	void setManagerPermission(boolean value);

} // BuildingManager
