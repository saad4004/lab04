/**
 */
package elevatorsystem.metamodel.elevatorsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevator Controls</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator <em>Moves Elevator</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions <em>Control Actions</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getSpeed <em>Speed</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getCapacity <em>Capacity</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isDoorOpenTime <em>Door Open Time</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isCurrentDirection <em>Current Direction</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls()
 * @model
 * @generated
 */
public interface ElevatorControls extends Elevator {
	/**
	 * Returns the value of the '<em><b>Moves Elevator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Moves Elevator</em>' reference.
	 * @see #setMovesElevator(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_MovesElevator()
	 * @model derived="true"
	 * @generated
	 */
	ElevatorDispatch getMovesElevator();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator <em>Moves Elevator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Moves Elevator</em>' reference.
	 * @see #getMovesElevator()
	 * @generated
	 */
	void setMovesElevator(ElevatorDispatch value);

	/**
	 * Returns the value of the '<em><b>Control Actions</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Control Actions</em>' reference.
	 * @see #setControlActions(Elevator)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_ControlActions()
	 * @model
	 * @generated
	 */
	Elevator getControlActions();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions <em>Control Actions</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Control Actions</em>' reference.
	 * @see #getControlActions()
	 * @generated
	 */
	void setControlActions(Elevator value);

	/**
	 * Returns the value of the '<em><b>Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Speed</em>' attribute.
	 * @see #setSpeed(int)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_Speed()
	 * @model
	 * @generated
	 */
	int getSpeed();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getSpeed <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Speed</em>' attribute.
	 * @see #getSpeed()
	 * @generated
	 */
	void setSpeed(int value);

	/**
	 * Returns the value of the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capacity</em>' attribute.
	 * @see #setCapacity(int)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_Capacity()
	 * @model
	 * @generated
	 */
	int getCapacity();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getCapacity <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capacity</em>' attribute.
	 * @see #getCapacity()
	 * @generated
	 */
	void setCapacity(int value);

	/**
	 * Returns the value of the '<em><b>Door Open Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Door Open Time</em>' attribute.
	 * @see #setDoorOpenTime(boolean)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_DoorOpenTime()
	 * @model
	 * @generated
	 */
	boolean isDoorOpenTime();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isDoorOpenTime <em>Door Open Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Door Open Time</em>' attribute.
	 * @see #isDoorOpenTime()
	 * @generated
	 */
	void setDoorOpenTime(boolean value);

	/**
	 * Returns the value of the '<em><b>Current Direction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Direction</em>' attribute.
	 * @see #setCurrentDirection(boolean)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_CurrentDirection()
	 * @model
	 * @generated
	 */
	boolean isCurrentDirection();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isCurrentDirection <em>Current Direction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Direction</em>' attribute.
	 * @see #isCurrentDirection()
	 * @generated
	 */
	void setCurrentDirection(boolean value);

} // ElevatorControls
