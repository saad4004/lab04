/**
 */
package elevatorsystem.metamodel.elevatorsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tenant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getUser <em>User</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getUnitNumber <em>Unit Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getLivesIn <em>Lives In</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getTenant()
 * @model
 * @generated
 */
public interface Tenant extends People {
	/**
	 * Returns the value of the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User</em>' reference.
	 * @see #setUser(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getTenant_User()
	 * @model
	 * @generated
	 */
	ElevatorDispatch getUser();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getUser <em>User</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User</em>' reference.
	 * @see #getUser()
	 * @generated
	 */
	void setUser(ElevatorDispatch value);

	/**
	 * Returns the value of the '<em><b>Unit Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Unit Number</em>' attribute.
	 * @see #setUnitNumber(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getTenant_UnitNumber()
	 * @model
	 * @generated
	 */
	String getUnitNumber();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getUnitNumber <em>Unit Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Unit Number</em>' attribute.
	 * @see #getUnitNumber()
	 * @generated
	 */
	void setUnitNumber(String value);

	/**
	 * Returns the value of the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone Number</em>' attribute.
	 * @see #setPhoneNumber(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getTenant_PhoneNumber()
	 * @model
	 * @generated
	 */
	String getPhoneNumber();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getPhoneNumber <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Phone Number</em>' attribute.
	 * @see #getPhoneNumber()
	 * @generated
	 */
	void setPhoneNumber(String value);

	/**
	 * Returns the value of the '<em><b>Lives In</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lives In</em>' reference.
	 * @see #setLivesIn(People)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getTenant_LivesIn()
	 * @model derived="true"
	 * @generated
	 */
	People getLivesIn();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getLivesIn <em>Lives In</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lives In</em>' reference.
	 * @see #getLivesIn()
	 * @generated
	 */
	void setLivesIn(People value);

} // Tenant
