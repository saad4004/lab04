/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevator Dispatch</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#isEmergencyOverride <em>Emergency Override</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getElevator <em>Elevator</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorDispatch()
 * @model
 * @generated
 */
public interface ElevatorDispatch extends EObject {
	/**
	 * Returns the value of the '<em><b>Emergency Override</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Emergency Override</em>' attribute.
	 * @see #setEmergencyOverride(boolean)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorDispatch_EmergencyOverride()
	 * @model id="true"
	 * @generated
	 */
	boolean isEmergencyOverride();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#isEmergencyOverride <em>Emergency Override</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Emergency Override</em>' attribute.
	 * @see #isEmergencyOverride()
	 * @generated
	 */
	void setEmergencyOverride(boolean value);

	/**
	 * Returns the value of the '<em><b>Elevator</b></em>' reference list.
	 * The list contents are of type {@link elevatorsystem.metamodel.elevatorsystem.Elevator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevator</em>' reference list.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorDispatch_Elevator()
	 * @model required="true" upper="2"
	 * @generated
	 */
	EList<Elevator> getElevator();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void optimizeRoutes();

} // ElevatorDispatch
