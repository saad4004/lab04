/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevator()
 * @model
 * @generated
 */
public interface Elevator extends EObject {
} // Elevator
