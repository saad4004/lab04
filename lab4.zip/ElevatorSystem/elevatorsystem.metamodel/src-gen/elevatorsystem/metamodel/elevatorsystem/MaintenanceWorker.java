/**
 */
package elevatorsystem.metamodel.elevatorsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Maintenance Worker</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getUser <em>User</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getEmployeeId <em>Employee Id</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getTechnicalSkills <em>Technical Skills</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getWorker <em>Worker</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getMaintenanceWorker()
 * @model
 * @generated
 */
public interface MaintenanceWorker extends People {
	/**
	 * Returns the value of the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User</em>' reference.
	 * @see #setUser(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getMaintenanceWorker_User()
	 * @model
	 * @generated
	 */
	ElevatorDispatch getUser();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getUser <em>User</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User</em>' reference.
	 * @see #getUser()
	 * @generated
	 */
	void setUser(ElevatorDispatch value);

	/**
	 * Returns the value of the '<em><b>Employee Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Employee Id</em>' attribute.
	 * @see #setEmployeeId(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getMaintenanceWorker_EmployeeId()
	 * @model
	 * @generated
	 */
	String getEmployeeId();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getEmployeeId <em>Employee Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Employee Id</em>' attribute.
	 * @see #getEmployeeId()
	 * @generated
	 */
	void setEmployeeId(String value);

	/**
	 * Returns the value of the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone Number</em>' attribute.
	 * @see #setPhoneNumber(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getMaintenanceWorker_PhoneNumber()
	 * @model
	 * @generated
	 */
	String getPhoneNumber();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getPhoneNumber <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Phone Number</em>' attribute.
	 * @see #getPhoneNumber()
	 * @generated
	 */
	void setPhoneNumber(String value);

	/**
	 * Returns the value of the '<em><b>Technical Skills</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Technical Skills</em>' attribute.
	 * @see #setTechnicalSkills(String)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getMaintenanceWorker_TechnicalSkills()
	 * @model
	 * @generated
	 */
	String getTechnicalSkills();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getTechnicalSkills <em>Technical Skills</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Technical Skills</em>' attribute.
	 * @see #getTechnicalSkills()
	 * @generated
	 */
	void setTechnicalSkills(String value);

	/**
	 * Returns the value of the '<em><b>Worker</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Worker</em>' reference.
	 * @see #setWorker(People)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getMaintenanceWorker_Worker()
	 * @model derived="true"
	 * @generated
	 */
	People getWorker();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getWorker <em>Worker</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Worker</em>' reference.
	 * @see #getWorker()
	 * @generated
	 */
	void setWorker(People value);

} // MaintenanceWorker
