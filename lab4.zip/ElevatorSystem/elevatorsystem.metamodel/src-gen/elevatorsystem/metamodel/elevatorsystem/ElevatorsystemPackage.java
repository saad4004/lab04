/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemFactory
 * @model kind="package"
 * @generated
 */
public interface ElevatorsystemPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "elevatorsystem";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/elevatorsystem";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "elevatorsystem";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ElevatorsystemPackage eINSTANCE = elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl.init();

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl <em>Building Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getBuildingManager()
	 * @generated
	 */
	int BUILDING_MANAGER = 0;

	/**
	 * The feature id for the '<em><b>Elevatormonitoring</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER__ELEVATORMONITORING = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER__NAME = 1;

	/**
	 * The feature id for the '<em><b>Employee Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER__EMPLOYEE_ID = 2;

	/**
	 * The feature id for the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER__PHONE_NUMBER = 3;

	/**
	 * The feature id for the '<em><b>Manager Permission</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER__MANAGER_PERMISSION = 4;

	/**
	 * The number of structural features of the '<em>Building Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Building Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl <em>Elevator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevator()
	 * @generated
	 */
	int ELEVATOR = 1;

	/**
	 * The number of structural features of the '<em>Elevator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Elevator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl <em>Elevator Monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorMonitoring()
	 * @generated
	 */
	int ELEVATOR_MONITORING = 2;

	/**
	 * The feature id for the '<em><b>Administrator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING__ADMINISTRATOR = 0;

	/**
	 * The feature id for the '<em><b>Generate Reports</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING__GENERATE_REPORTS = 1;

	/**
	 * The number of structural features of the '<em>Elevator Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Status Alert Thresholds</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING___STATUS_ALERT_THRESHOLDS = 0;

	/**
	 * The number of operations of the '<em>Elevator Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.PeopleImpl <em>People</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.PeopleImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getPeople()
	 * @generated
	 */
	int PEOPLE = 8;

	/**
	 * The feature id for the '<em><b>Participants</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PEOPLE__PARTICIPANTS = 0;

	/**
	 * The feature id for the '<em><b>Users</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PEOPLE__USERS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PEOPLE__NAME = 2;

	/**
	 * The number of structural features of the '<em>People</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PEOPLE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>People</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PEOPLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl <em>Maintenance Worker</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getMaintenanceWorker()
	 * @generated
	 */
	int MAINTENANCE_WORKER = 3;

	/**
	 * The feature id for the '<em><b>Participants</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__PARTICIPANTS = PEOPLE__PARTICIPANTS;

	/**
	 * The feature id for the '<em><b>Users</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__USERS = PEOPLE__USERS;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__NAME = PEOPLE__NAME;

	/**
	 * The feature id for the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__USER = PEOPLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Employee Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__EMPLOYEE_ID = PEOPLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__PHONE_NUMBER = PEOPLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Technical Skills</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__TECHNICAL_SKILLS = PEOPLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Worker</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__WORKER = PEOPLE_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Maintenance Worker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER_FEATURE_COUNT = PEOPLE_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Maintenance Worker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER_OPERATION_COUNT = PEOPLE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl <em>Tenant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getTenant()
	 * @generated
	 */
	int TENANT = 4;

	/**
	 * The feature id for the '<em><b>Participants</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__PARTICIPANTS = PEOPLE__PARTICIPANTS;

	/**
	 * The feature id for the '<em><b>Users</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__USERS = PEOPLE__USERS;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__NAME = PEOPLE__NAME;

	/**
	 * The feature id for the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__USER = PEOPLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Unit Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__UNIT_NUMBER = PEOPLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__PHONE_NUMBER = PEOPLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Lives In</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__LIVES_IN = PEOPLE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Tenant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT_FEATURE_COUNT = PEOPLE_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Tenant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT_OPERATION_COUNT = PEOPLE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl <em>Deliver Person</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getDeliverPerson()
	 * @generated
	 */
	int DELIVER_PERSON = 5;

	/**
	 * The feature id for the '<em><b>Participants</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__PARTICIPANTS = PEOPLE__PARTICIPANTS;

	/**
	 * The feature id for the '<em><b>Users</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__USERS = PEOPLE__USERS;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__NAME = PEOPLE__NAME;

	/**
	 * The feature id for the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__USER = PEOPLE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Employee Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__EMPLOYEE_ID = PEOPLE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__PHONE_NUMBER = PEOPLE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Packages</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__PACKAGES = PEOPLE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Work Momentarly</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__WORK_MOMENTARLY = PEOPLE_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Deliver Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON_FEATURE_COUNT = PEOPLE_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Deliver Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON_OPERATION_COUNT = PEOPLE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl <em>Elevator Controls</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorControls()
	 * @generated
	 */
	int ELEVATOR_CONTROLS = 6;

	/**
	 * The feature id for the '<em><b>Moves Elevator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__MOVES_ELEVATOR = ELEVATOR_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Control Actions</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__CONTROL_ACTIONS = ELEVATOR_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__SPEED = ELEVATOR_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__CAPACITY = ELEVATOR_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Door Open Time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__DOOR_OPEN_TIME = ELEVATOR_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Current Direction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__CURRENT_DIRECTION = ELEVATOR_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Elevator Controls</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS_FEATURE_COUNT = ELEVATOR_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Elevator Controls</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS_OPERATION_COUNT = ELEVATOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl <em>Elevator Dispatch</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorDispatch()
	 * @generated
	 */
	int ELEVATOR_DISPATCH = 7;

	/**
	 * The feature id for the '<em><b>Emergency Override</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH__EMERGENCY_OVERRIDE = 0;

	/**
	 * The feature id for the '<em><b>Elevator</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH__ELEVATOR = 1;

	/**
	 * The number of structural features of the '<em>Elevator Dispatch</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Optimize Routes</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH___OPTIMIZE_ROUTES = 0;

	/**
	 * The number of operations of the '<em>Elevator Dispatch</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.EsmodelImpl <em>Esmodel</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.EsmodelImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getEsmodel()
	 * @generated
	 */
	int ESMODEL = 9;

	/**
	 * The feature id for the '<em><b>Elevatordispatch</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ESMODEL__ELEVATORDISPATCH = 0;

	/**
	 * The feature id for the '<em><b>People</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ESMODEL__PEOPLE = 1;

	/**
	 * The feature id for the '<em><b>Elevator</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ESMODEL__ELEVATOR = 2;

	/**
	 * The number of structural features of the '<em>Esmodel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ESMODEL_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Esmodel</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ESMODEL_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager <em>Building Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Building Manager</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager
	 * @generated
	 */
	EClass getBuildingManager();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring <em>Elevatormonitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Elevatormonitoring</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring()
	 * @see #getBuildingManager()
	 * @generated
	 */
	EReference getBuildingManager_Elevatormonitoring();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager#getName()
	 * @see #getBuildingManager()
	 * @generated
	 */
	EAttribute getBuildingManager_Name();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getEmployeeId <em>Employee Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Employee Id</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager#getEmployeeId()
	 * @see #getBuildingManager()
	 * @generated
	 */
	EAttribute getBuildingManager_EmployeeId();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getPhoneNumber <em>Phone Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Phone Number</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager#getPhoneNumber()
	 * @see #getBuildingManager()
	 * @generated
	 */
	EAttribute getBuildingManager_PhoneNumber();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#isManagerPermission <em>Manager Permission</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manager Permission</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager#isManagerPermission()
	 * @see #getBuildingManager()
	 * @generated
	 */
	EAttribute getBuildingManager_ManagerPermission();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.Elevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Elevator
	 * @generated
	 */
	EClass getElevator();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring <em>Elevator Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator Monitoring</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring
	 * @generated
	 */
	EClass getElevatorMonitoring();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getAdministrator <em>Administrator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Administrator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getAdministrator()
	 * @see #getElevatorMonitoring()
	 * @generated
	 */
	EReference getElevatorMonitoring_Administrator();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getGenerateReports <em>Generate Reports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Generate Reports</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getGenerateReports()
	 * @see #getElevatorMonitoring()
	 * @generated
	 */
	EAttribute getElevatorMonitoring_GenerateReports();

	/**
	 * Returns the meta object for the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#statusAlertThresholds() <em>Status Alert Thresholds</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Status Alert Thresholds</em>' operation.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#statusAlertThresholds()
	 * @generated
	 */
	EOperation getElevatorMonitoring__StatusAlertThresholds();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker <em>Maintenance Worker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Maintenance Worker</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker
	 * @generated
	 */
	EClass getMaintenanceWorker();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getUser()
	 * @see #getMaintenanceWorker()
	 * @generated
	 */
	EReference getMaintenanceWorker_User();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getEmployeeId <em>Employee Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Employee Id</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getEmployeeId()
	 * @see #getMaintenanceWorker()
	 * @generated
	 */
	EAttribute getMaintenanceWorker_EmployeeId();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getPhoneNumber <em>Phone Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Phone Number</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getPhoneNumber()
	 * @see #getMaintenanceWorker()
	 * @generated
	 */
	EAttribute getMaintenanceWorker_PhoneNumber();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getTechnicalSkills <em>Technical Skills</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Technical Skills</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getTechnicalSkills()
	 * @see #getMaintenanceWorker()
	 * @generated
	 */
	EAttribute getMaintenanceWorker_TechnicalSkills();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getWorker <em>Worker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Worker</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getWorker()
	 * @see #getMaintenanceWorker()
	 * @generated
	 */
	EReference getMaintenanceWorker_Worker();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.Tenant <em>Tenant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tenant</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant
	 * @generated
	 */
	EClass getTenant();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant#getUser()
	 * @see #getTenant()
	 * @generated
	 */
	EReference getTenant_User();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getUnitNumber <em>Unit Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Unit Number</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant#getUnitNumber()
	 * @see #getTenant()
	 * @generated
	 */
	EAttribute getTenant_UnitNumber();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getPhoneNumber <em>Phone Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Phone Number</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant#getPhoneNumber()
	 * @see #getTenant()
	 * @generated
	 */
	EAttribute getTenant_PhoneNumber();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getLivesIn <em>Lives In</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lives In</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant#getLivesIn()
	 * @see #getTenant()
	 * @generated
	 */
	EReference getTenant_LivesIn();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson <em>Deliver Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Deliver Person</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson
	 * @generated
	 */
	EClass getDeliverPerson();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getUser()
	 * @see #getDeliverPerson()
	 * @generated
	 */
	EReference getDeliverPerson_User();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getEmployeeId <em>Employee Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Employee Id</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getEmployeeId()
	 * @see #getDeliverPerson()
	 * @generated
	 */
	EAttribute getDeliverPerson_EmployeeId();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPhoneNumber <em>Phone Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Phone Number</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPhoneNumber()
	 * @see #getDeliverPerson()
	 * @generated
	 */
	EAttribute getDeliverPerson_PhoneNumber();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPackages <em>Packages</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Packages</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getPackages()
	 * @see #getDeliverPerson()
	 * @generated
	 */
	EAttribute getDeliverPerson_Packages();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getWorkMomentarly <em>Work Momentarly</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Work Momentarly</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getWorkMomentarly()
	 * @see #getDeliverPerson()
	 * @generated
	 */
	EReference getDeliverPerson_WorkMomentarly();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls <em>Elevator Controls</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator Controls</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls
	 * @generated
	 */
	EClass getElevatorControls();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator <em>Moves Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Moves Elevator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EReference getElevatorControls_MovesElevator();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions <em>Control Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Control Actions</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EReference getElevatorControls_ControlActions();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getSpeed <em>Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Speed</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getSpeed()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EAttribute getElevatorControls_Speed();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getCapacity <em>Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capacity</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getCapacity()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EAttribute getElevatorControls_Capacity();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isDoorOpenTime <em>Door Open Time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Door Open Time</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isDoorOpenTime()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EAttribute getElevatorControls_DoorOpenTime();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isCurrentDirection <em>Current Direction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Direction</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#isCurrentDirection()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EAttribute getElevatorControls_CurrentDirection();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch <em>Elevator Dispatch</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator Dispatch</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch
	 * @generated
	 */
	EClass getElevatorDispatch();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#isEmergencyOverride <em>Emergency Override</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Emergency Override</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#isEmergencyOverride()
	 * @see #getElevatorDispatch()
	 * @generated
	 */
	EAttribute getElevatorDispatch_EmergencyOverride();

	/**
	 * Returns the meta object for the reference list '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getElevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Elevator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getElevator()
	 * @see #getElevatorDispatch()
	 * @generated
	 */
	EReference getElevatorDispatch_Elevator();

	/**
	 * Returns the meta object for the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#optimizeRoutes() <em>Optimize Routes</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Optimize Routes</em>' operation.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#optimizeRoutes()
	 * @generated
	 */
	EOperation getElevatorDispatch__OptimizeRoutes();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.People <em>People</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>People</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.People
	 * @generated
	 */
	EClass getPeople();

	/**
	 * Returns the meta object for the reference list '{@link elevatorsystem.metamodel.elevatorsystem.People#getParticipants <em>Participants</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Participants</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.People#getParticipants()
	 * @see #getPeople()
	 * @generated
	 */
	EReference getPeople_Participants();

	/**
	 * Returns the meta object for the reference list '{@link elevatorsystem.metamodel.elevatorsystem.People#getUsers <em>Users</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Users</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.People#getUsers()
	 * @see #getPeople()
	 * @generated
	 */
	EReference getPeople_Users();

	/**
	 * Returns the meta object for the attribute '{@link elevatorsystem.metamodel.elevatorsystem.People#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.People#getName()
	 * @see #getPeople()
	 * @generated
	 */
	EAttribute getPeople_Name();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.Esmodel <em>Esmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Esmodel</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Esmodel
	 * @generated
	 */
	EClass getEsmodel();

	/**
	 * Returns the meta object for the containment reference list '{@link elevatorsystem.metamodel.elevatorsystem.Esmodel#getElevatordispatch <em>Elevatordispatch</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Elevatordispatch</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Esmodel#getElevatordispatch()
	 * @see #getEsmodel()
	 * @generated
	 */
	EReference getEsmodel_Elevatordispatch();

	/**
	 * Returns the meta object for the containment reference list '{@link elevatorsystem.metamodel.elevatorsystem.Esmodel#getPeople <em>People</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>People</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Esmodel#getPeople()
	 * @see #getEsmodel()
	 * @generated
	 */
	EReference getEsmodel_People();

	/**
	 * Returns the meta object for the containment reference list '{@link elevatorsystem.metamodel.elevatorsystem.Esmodel#getElevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Elevator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Esmodel#getElevator()
	 * @see #getEsmodel()
	 * @generated
	 */
	EReference getEsmodel_Elevator();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ElevatorsystemFactory getElevatorsystemFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl <em>Building Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getBuildingManager()
		 * @generated
		 */
		EClass BUILDING_MANAGER = eINSTANCE.getBuildingManager();

		/**
		 * The meta object literal for the '<em><b>Elevatormonitoring</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUILDING_MANAGER__ELEVATORMONITORING = eINSTANCE.getBuildingManager_Elevatormonitoring();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUILDING_MANAGER__NAME = eINSTANCE.getBuildingManager_Name();

		/**
		 * The meta object literal for the '<em><b>Employee Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUILDING_MANAGER__EMPLOYEE_ID = eINSTANCE.getBuildingManager_EmployeeId();

		/**
		 * The meta object literal for the '<em><b>Phone Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUILDING_MANAGER__PHONE_NUMBER = eINSTANCE.getBuildingManager_PhoneNumber();

		/**
		 * The meta object literal for the '<em><b>Manager Permission</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUILDING_MANAGER__MANAGER_PERMISSION = eINSTANCE.getBuildingManager_ManagerPermission();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl <em>Elevator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevator()
		 * @generated
		 */
		EClass ELEVATOR = eINSTANCE.getElevator();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl <em>Elevator Monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorMonitoring()
		 * @generated
		 */
		EClass ELEVATOR_MONITORING = eINSTANCE.getElevatorMonitoring();

		/**
		 * The meta object literal for the '<em><b>Administrator</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_MONITORING__ADMINISTRATOR = eINSTANCE.getElevatorMonitoring_Administrator();

		/**
		 * The meta object literal for the '<em><b>Generate Reports</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR_MONITORING__GENERATE_REPORTS = eINSTANCE.getElevatorMonitoring_GenerateReports();

		/**
		 * The meta object literal for the '<em><b>Status Alert Thresholds</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ELEVATOR_MONITORING___STATUS_ALERT_THRESHOLDS = eINSTANCE
				.getElevatorMonitoring__StatusAlertThresholds();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl <em>Maintenance Worker</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getMaintenanceWorker()
		 * @generated
		 */
		EClass MAINTENANCE_WORKER = eINSTANCE.getMaintenanceWorker();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAINTENANCE_WORKER__USER = eINSTANCE.getMaintenanceWorker_User();

		/**
		 * The meta object literal for the '<em><b>Employee Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAINTENANCE_WORKER__EMPLOYEE_ID = eINSTANCE.getMaintenanceWorker_EmployeeId();

		/**
		 * The meta object literal for the '<em><b>Phone Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAINTENANCE_WORKER__PHONE_NUMBER = eINSTANCE.getMaintenanceWorker_PhoneNumber();

		/**
		 * The meta object literal for the '<em><b>Technical Skills</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MAINTENANCE_WORKER__TECHNICAL_SKILLS = eINSTANCE.getMaintenanceWorker_TechnicalSkills();

		/**
		 * The meta object literal for the '<em><b>Worker</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAINTENANCE_WORKER__WORKER = eINSTANCE.getMaintenanceWorker_Worker();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl <em>Tenant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getTenant()
		 * @generated
		 */
		EClass TENANT = eINSTANCE.getTenant();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TENANT__USER = eINSTANCE.getTenant_User();

		/**
		 * The meta object literal for the '<em><b>Unit Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TENANT__UNIT_NUMBER = eINSTANCE.getTenant_UnitNumber();

		/**
		 * The meta object literal for the '<em><b>Phone Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TENANT__PHONE_NUMBER = eINSTANCE.getTenant_PhoneNumber();

		/**
		 * The meta object literal for the '<em><b>Lives In</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TENANT__LIVES_IN = eINSTANCE.getTenant_LivesIn();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl <em>Deliver Person</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getDeliverPerson()
		 * @generated
		 */
		EClass DELIVER_PERSON = eINSTANCE.getDeliverPerson();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELIVER_PERSON__USER = eINSTANCE.getDeliverPerson_User();

		/**
		 * The meta object literal for the '<em><b>Employee Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELIVER_PERSON__EMPLOYEE_ID = eINSTANCE.getDeliverPerson_EmployeeId();

		/**
		 * The meta object literal for the '<em><b>Phone Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELIVER_PERSON__PHONE_NUMBER = eINSTANCE.getDeliverPerson_PhoneNumber();

		/**
		 * The meta object literal for the '<em><b>Packages</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DELIVER_PERSON__PACKAGES = eINSTANCE.getDeliverPerson_Packages();

		/**
		 * The meta object literal for the '<em><b>Work Momentarly</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELIVER_PERSON__WORK_MOMENTARLY = eINSTANCE.getDeliverPerson_WorkMomentarly();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl <em>Elevator Controls</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorControls()
		 * @generated
		 */
		EClass ELEVATOR_CONTROLS = eINSTANCE.getElevatorControls();

		/**
		 * The meta object literal for the '<em><b>Moves Elevator</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_CONTROLS__MOVES_ELEVATOR = eINSTANCE.getElevatorControls_MovesElevator();

		/**
		 * The meta object literal for the '<em><b>Control Actions</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_CONTROLS__CONTROL_ACTIONS = eINSTANCE.getElevatorControls_ControlActions();

		/**
		 * The meta object literal for the '<em><b>Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR_CONTROLS__SPEED = eINSTANCE.getElevatorControls_Speed();

		/**
		 * The meta object literal for the '<em><b>Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR_CONTROLS__CAPACITY = eINSTANCE.getElevatorControls_Capacity();

		/**
		 * The meta object literal for the '<em><b>Door Open Time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR_CONTROLS__DOOR_OPEN_TIME = eINSTANCE.getElevatorControls_DoorOpenTime();

		/**
		 * The meta object literal for the '<em><b>Current Direction</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR_CONTROLS__CURRENT_DIRECTION = eINSTANCE.getElevatorControls_CurrentDirection();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl <em>Elevator Dispatch</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorDispatch()
		 * @generated
		 */
		EClass ELEVATOR_DISPATCH = eINSTANCE.getElevatorDispatch();

		/**
		 * The meta object literal for the '<em><b>Emergency Override</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEVATOR_DISPATCH__EMERGENCY_OVERRIDE = eINSTANCE.getElevatorDispatch_EmergencyOverride();

		/**
		 * The meta object literal for the '<em><b>Elevator</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_DISPATCH__ELEVATOR = eINSTANCE.getElevatorDispatch_Elevator();

		/**
		 * The meta object literal for the '<em><b>Optimize Routes</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ELEVATOR_DISPATCH___OPTIMIZE_ROUTES = eINSTANCE.getElevatorDispatch__OptimizeRoutes();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.PeopleImpl <em>People</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.PeopleImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getPeople()
		 * @generated
		 */
		EClass PEOPLE = eINSTANCE.getPeople();

		/**
		 * The meta object literal for the '<em><b>Participants</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PEOPLE__PARTICIPANTS = eINSTANCE.getPeople_Participants();

		/**
		 * The meta object literal for the '<em><b>Users</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PEOPLE__USERS = eINSTANCE.getPeople_Users();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PEOPLE__NAME = eINSTANCE.getPeople_Name();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.EsmodelImpl <em>Esmodel</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.EsmodelImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getEsmodel()
		 * @generated
		 */
		EClass ESMODEL = eINSTANCE.getEsmodel();

		/**
		 * The meta object literal for the '<em><b>Elevatordispatch</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ESMODEL__ELEVATORDISPATCH = eINSTANCE.getEsmodel_Elevatordispatch();

		/**
		 * The meta object literal for the '<em><b>People</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ESMODEL__PEOPLE = eINSTANCE.getEsmodel_People();

		/**
		 * The meta object literal for the '<em><b>Elevator</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ESMODEL__ELEVATOR = eINSTANCE.getEsmodel_Elevator();

	}

} //ElevatorsystemPackage
