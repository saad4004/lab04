/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Esmodel</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.Esmodel#getElevatordispatch <em>Elevatordispatch</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.Esmodel#getPeople <em>People</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.Esmodel#getElevator <em>Elevator</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getEsmodel()
 * @model
 * @generated
 */
public interface Esmodel extends EObject {
	/**
	 * Returns the value of the '<em><b>Elevatordispatch</b></em>' containment reference list.
	 * The list contents are of type {@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevatordispatch</em>' containment reference list.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getEsmodel_Elevatordispatch()
	 * @model containment="true"
	 * @generated
	 */
	EList<ElevatorDispatch> getElevatordispatch();

	/**
	 * Returns the value of the '<em><b>People</b></em>' containment reference list.
	 * The list contents are of type {@link elevatorsystem.metamodel.elevatorsystem.People}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>People</em>' containment reference list.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getEsmodel_People()
	 * @model containment="true"
	 * @generated
	 */
	EList<People> getPeople();

	/**
	 * Returns the value of the '<em><b>Elevator</b></em>' containment reference list.
	 * The list contents are of type {@link elevatorsystem.metamodel.elevatorsystem.Elevator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevator</em>' containment reference list.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getEsmodel_Elevator()
	 * @model containment="true"
	 * @generated
	 */
	EList<Elevator> getElevator();

} // Esmodel
