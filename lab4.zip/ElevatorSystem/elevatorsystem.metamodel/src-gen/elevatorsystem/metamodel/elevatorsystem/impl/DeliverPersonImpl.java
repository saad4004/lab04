/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.DeliverPerson;
import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;

import elevatorsystem.metamodel.elevatorsystem.People;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Deliver Person</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl#getUser <em>User</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl#getEmployeeId <em>Employee Id</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl#getPackages <em>Packages</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl#getWorkMomentarly <em>Work Momentarly</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DeliverPersonImpl extends PeopleImpl implements DeliverPerson {
	/**
	 * The cached value of the '{@link #getUser() <em>User</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUser()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch user;

	/**
	 * The default value of the '{@link #getEmployeeId() <em>Employee Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmployeeId()
	 * @generated
	 * @ordered
	 */
	protected static final String EMPLOYEE_ID_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getEmployeeId() <em>Employee Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmployeeId()
	 * @generated
	 * @ordered
	 */
	protected String employeeId = EMPLOYEE_ID_EDEFAULT;
	/**
	 * The default value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String PHONE_NUMBER_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected String phoneNumber = PHONE_NUMBER_EDEFAULT;
	/**
	 * The default value of the '{@link #getPackages() <em>Packages</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPackages()
	 * @generated
	 * @ordered
	 */
	protected static final int PACKAGES_EDEFAULT = 0;
	/**
	 * The cached value of the '{@link #getPackages() <em>Packages</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPackages()
	 * @generated
	 * @ordered
	 */
	protected int packages = PACKAGES_EDEFAULT;
	/**
	 * The cached value of the '{@link #getWorkMomentarly() <em>Work Momentarly</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWorkMomentarly()
	 * @generated
	 * @ordered
	 */
	protected People workMomentarly;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DeliverPersonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.DELIVER_PERSON;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getUser() {
		if (user != null && user.eIsProxy()) {
			InternalEObject oldUser = (InternalEObject) user;
			user = (ElevatorDispatch) eResolveProxy(oldUser);
			if (user != oldUser) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.DELIVER_PERSON__USER, oldUser, user));
			}
		}
		return user;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetUser() {
		return user;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUser(ElevatorDispatch newUser) {
		ElevatorDispatch oldUser = user;
		user = newUser;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.DELIVER_PERSON__USER, oldUser,
					user));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmployeeId(String newEmployeeId) {
		String oldEmployeeId = employeeId;
		employeeId = newEmployeeId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.DELIVER_PERSON__EMPLOYEE_ID,
					oldEmployeeId, employeeId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhoneNumber(String newPhoneNumber) {
		String oldPhoneNumber = phoneNumber;
		phoneNumber = newPhoneNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.DELIVER_PERSON__PHONE_NUMBER,
					oldPhoneNumber, phoneNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPackages() {
		return packages;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPackages(int newPackages) {
		int oldPackages = packages;
		packages = newPackages;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.DELIVER_PERSON__PACKAGES,
					oldPackages, packages));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public People getWorkMomentarly() {
		if (workMomentarly != null && workMomentarly.eIsProxy()) {
			InternalEObject oldWorkMomentarly = (InternalEObject) workMomentarly;
			workMomentarly = (People) eResolveProxy(oldWorkMomentarly);
			if (workMomentarly != oldWorkMomentarly) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.DELIVER_PERSON__WORK_MOMENTARLY, oldWorkMomentarly, workMomentarly));
			}
		}
		return workMomentarly;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public People basicGetWorkMomentarly() {
		return workMomentarly;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWorkMomentarly(People newWorkMomentarly) {
		People oldWorkMomentarly = workMomentarly;
		workMomentarly = newWorkMomentarly;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.DELIVER_PERSON__WORK_MOMENTARLY,
					oldWorkMomentarly, workMomentarly));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.DELIVER_PERSON__USER:
			if (resolve)
				return getUser();
			return basicGetUser();
		case ElevatorsystemPackage.DELIVER_PERSON__EMPLOYEE_ID:
			return getEmployeeId();
		case ElevatorsystemPackage.DELIVER_PERSON__PHONE_NUMBER:
			return getPhoneNumber();
		case ElevatorsystemPackage.DELIVER_PERSON__PACKAGES:
			return getPackages();
		case ElevatorsystemPackage.DELIVER_PERSON__WORK_MOMENTARLY:
			if (resolve)
				return getWorkMomentarly();
			return basicGetWorkMomentarly();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.DELIVER_PERSON__USER:
			setUser((ElevatorDispatch) newValue);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__EMPLOYEE_ID:
			setEmployeeId((String) newValue);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__PHONE_NUMBER:
			setPhoneNumber((String) newValue);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__PACKAGES:
			setPackages((Integer) newValue);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__WORK_MOMENTARLY:
			setWorkMomentarly((People) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.DELIVER_PERSON__USER:
			setUser((ElevatorDispatch) null);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__EMPLOYEE_ID:
			setEmployeeId(EMPLOYEE_ID_EDEFAULT);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__PHONE_NUMBER:
			setPhoneNumber(PHONE_NUMBER_EDEFAULT);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__PACKAGES:
			setPackages(PACKAGES_EDEFAULT);
			return;
		case ElevatorsystemPackage.DELIVER_PERSON__WORK_MOMENTARLY:
			setWorkMomentarly((People) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.DELIVER_PERSON__USER:
			return user != null;
		case ElevatorsystemPackage.DELIVER_PERSON__EMPLOYEE_ID:
			return EMPLOYEE_ID_EDEFAULT == null ? employeeId != null : !EMPLOYEE_ID_EDEFAULT.equals(employeeId);
		case ElevatorsystemPackage.DELIVER_PERSON__PHONE_NUMBER:
			return PHONE_NUMBER_EDEFAULT == null ? phoneNumber != null : !PHONE_NUMBER_EDEFAULT.equals(phoneNumber);
		case ElevatorsystemPackage.DELIVER_PERSON__PACKAGES:
			return packages != PACKAGES_EDEFAULT;
		case ElevatorsystemPackage.DELIVER_PERSON__WORK_MOMENTARLY:
			return workMomentarly != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (employeeId: ");
		result.append(employeeId);
		result.append(", phoneNumber: ");
		result.append(phoneNumber);
		result.append(", packages: ");
		result.append(packages);
		result.append(')');
		return result.toString();
	}

} //DeliverPersonImpl
