/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.Elevator;
import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elevator Dispatch</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl#isEmergencyOverride <em>Emergency Override</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl#getElevator <em>Elevator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElevatorDispatchImpl extends MinimalEObjectImpl.Container implements ElevatorDispatch {
	/**
	 * The default value of the '{@link #isEmergencyOverride() <em>Emergency Override</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isEmergencyOverride()
	 * @generated
	 * @ordered
	 */
	protected static final boolean EMERGENCY_OVERRIDE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isEmergencyOverride() <em>Emergency Override</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isEmergencyOverride()
	 * @generated
	 * @ordered
	 */
	protected boolean emergencyOverride = EMERGENCY_OVERRIDE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getElevator() <em>Elevator</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElevator()
	 * @generated
	 * @ordered
	 */
	protected EList<Elevator> elevator;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevatorDispatchImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.ELEVATOR_DISPATCH;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isEmergencyOverride() {
		return emergencyOverride;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmergencyOverride(boolean newEmergencyOverride) {
		boolean oldEmergencyOverride = emergencyOverride;
		emergencyOverride = newEmergencyOverride;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_DISPATCH__EMERGENCY_OVERRIDE, oldEmergencyOverride,
					emergencyOverride));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Elevator> getElevator() {
		if (elevator == null) {
			elevator = new EObjectResolvingEList<Elevator>(Elevator.class, this,
					ElevatorsystemPackage.ELEVATOR_DISPATCH__ELEVATOR);
		}
		return elevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void optimizeRoutes() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__EMERGENCY_OVERRIDE:
			return isEmergencyOverride();
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ELEVATOR:
			return getElevator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__EMERGENCY_OVERRIDE:
			setEmergencyOverride((Boolean) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ELEVATOR:
			getElevator().clear();
			getElevator().addAll((Collection<? extends Elevator>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__EMERGENCY_OVERRIDE:
			setEmergencyOverride(EMERGENCY_OVERRIDE_EDEFAULT);
			return;
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ELEVATOR:
			getElevator().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__EMERGENCY_OVERRIDE:
			return emergencyOverride != EMERGENCY_OVERRIDE_EDEFAULT;
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ELEVATOR:
			return elevator != null && !elevator.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH___OPTIMIZE_ROUTES:
			optimizeRoutes();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (emergencyOverride: ");
		result.append(emergencyOverride);
		result.append(')');
		return result.toString();
	}

} //ElevatorDispatchImpl
