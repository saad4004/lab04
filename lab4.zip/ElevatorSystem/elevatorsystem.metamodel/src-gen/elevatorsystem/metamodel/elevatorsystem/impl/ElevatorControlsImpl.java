/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.Elevator;
import elevatorsystem.metamodel.elevatorsystem.ElevatorControls;
import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elevator Controls</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#getMovesElevator <em>Moves Elevator</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#getControlActions <em>Control Actions</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#getSpeed <em>Speed</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#getCapacity <em>Capacity</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#isDoorOpenTime <em>Door Open Time</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#isCurrentDirection <em>Current Direction</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElevatorControlsImpl extends ElevatorImpl implements ElevatorControls {
	/**
	 * The cached value of the '{@link #getMovesElevator() <em>Moves Elevator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMovesElevator()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch movesElevator;

	/**
	 * The cached value of the '{@link #getControlActions() <em>Control Actions</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlActions()
	 * @generated
	 * @ordered
	 */
	protected Elevator controlActions;

	/**
	 * The default value of the '{@link #getSpeed() <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeed()
	 * @generated
	 * @ordered
	 */
	protected static final int SPEED_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getSpeed() <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeed()
	 * @generated
	 * @ordered
	 */
	protected int speed = SPEED_EDEFAULT;

	/**
	 * The default value of the '{@link #getCapacity() <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapacity()
	 * @generated
	 * @ordered
	 */
	protected static final int CAPACITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCapacity() <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapacity()
	 * @generated
	 * @ordered
	 */
	protected int capacity = CAPACITY_EDEFAULT;

	/**
	 * The default value of the '{@link #isDoorOpenTime() <em>Door Open Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDoorOpenTime()
	 * @generated
	 * @ordered
	 */
	protected static final boolean DOOR_OPEN_TIME_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isDoorOpenTime() <em>Door Open Time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDoorOpenTime()
	 * @generated
	 * @ordered
	 */
	protected boolean doorOpenTime = DOOR_OPEN_TIME_EDEFAULT;

	/**
	 * The default value of the '{@link #isCurrentDirection() <em>Current Direction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCurrentDirection()
	 * @generated
	 * @ordered
	 */
	protected static final boolean CURRENT_DIRECTION_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isCurrentDirection() <em>Current Direction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCurrentDirection()
	 * @generated
	 * @ordered
	 */
	protected boolean currentDirection = CURRENT_DIRECTION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevatorControlsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.ELEVATOR_CONTROLS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getMovesElevator() {
		if (movesElevator != null && movesElevator.eIsProxy()) {
			InternalEObject oldMovesElevator = (InternalEObject) movesElevator;
			movesElevator = (ElevatorDispatch) eResolveProxy(oldMovesElevator);
			if (movesElevator != oldMovesElevator) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR, oldMovesElevator, movesElevator));
			}
		}
		return movesElevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetMovesElevator() {
		return movesElevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMovesElevator(ElevatorDispatch newMovesElevator) {
		ElevatorDispatch oldMovesElevator = movesElevator;
		movesElevator = newMovesElevator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR, oldMovesElevator, movesElevator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Elevator getControlActions() {
		if (controlActions != null && controlActions.eIsProxy()) {
			InternalEObject oldControlActions = (InternalEObject) controlActions;
			controlActions = (Elevator) eResolveProxy(oldControlActions);
			if (controlActions != oldControlActions) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS, oldControlActions,
							controlActions));
			}
		}
		return controlActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Elevator basicGetControlActions() {
		return controlActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setControlActions(Elevator newControlActions) {
		Elevator oldControlActions = controlActions;
		controlActions = newControlActions;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS, oldControlActions, controlActions));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSpeed() {
		return speed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSpeed(int newSpeed) {
		int oldSpeed = speed;
		speed = newSpeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.ELEVATOR_CONTROLS__SPEED,
					oldSpeed, speed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapacity(int newCapacity) {
		int oldCapacity = capacity;
		capacity = newCapacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.ELEVATOR_CONTROLS__CAPACITY,
					oldCapacity, capacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isDoorOpenTime() {
		return doorOpenTime;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoorOpenTime(boolean newDoorOpenTime) {
		boolean oldDoorOpenTime = doorOpenTime;
		doorOpenTime = newDoorOpenTime;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_CONTROLS__DOOR_OPEN_TIME, oldDoorOpenTime, doorOpenTime));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isCurrentDirection() {
		return currentDirection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCurrentDirection(boolean newCurrentDirection) {
		boolean oldCurrentDirection = currentDirection;
		currentDirection = newCurrentDirection;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_CONTROLS__CURRENT_DIRECTION, oldCurrentDirection, currentDirection));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			if (resolve)
				return getMovesElevator();
			return basicGetMovesElevator();
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			if (resolve)
				return getControlActions();
			return basicGetControlActions();
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__SPEED:
			return getSpeed();
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CAPACITY:
			return getCapacity();
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__DOOR_OPEN_TIME:
			return isDoorOpenTime();
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CURRENT_DIRECTION:
			return isCurrentDirection();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			setMovesElevator((ElevatorDispatch) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			setControlActions((Elevator) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__SPEED:
			setSpeed((Integer) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CAPACITY:
			setCapacity((Integer) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__DOOR_OPEN_TIME:
			setDoorOpenTime((Boolean) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CURRENT_DIRECTION:
			setCurrentDirection((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			setMovesElevator((ElevatorDispatch) null);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			setControlActions((Elevator) null);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__SPEED:
			setSpeed(SPEED_EDEFAULT);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CAPACITY:
			setCapacity(CAPACITY_EDEFAULT);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__DOOR_OPEN_TIME:
			setDoorOpenTime(DOOR_OPEN_TIME_EDEFAULT);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CURRENT_DIRECTION:
			setCurrentDirection(CURRENT_DIRECTION_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			return movesElevator != null;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			return controlActions != null;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__SPEED:
			return speed != SPEED_EDEFAULT;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CAPACITY:
			return capacity != CAPACITY_EDEFAULT;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__DOOR_OPEN_TIME:
			return doorOpenTime != DOOR_OPEN_TIME_EDEFAULT;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CURRENT_DIRECTION:
			return currentDirection != CURRENT_DIRECTION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (speed: ");
		result.append(speed);
		result.append(", capacity: ");
		result.append(capacity);
		result.append(", doorOpenTime: ");
		result.append(doorOpenTime);
		result.append(", currentDirection: ");
		result.append(currentDirection);
		result.append(')');
		return result.toString();
	}

} //ElevatorControlsImpl
