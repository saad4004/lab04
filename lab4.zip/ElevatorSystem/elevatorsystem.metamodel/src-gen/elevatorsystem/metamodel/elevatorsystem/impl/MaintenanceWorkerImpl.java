/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;
import elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker;

import elevatorsystem.metamodel.elevatorsystem.People;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Maintenance Worker</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl#getUser <em>User</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl#getEmployeeId <em>Employee Id</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl#getTechnicalSkills <em>Technical Skills</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl#getWorker <em>Worker</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MaintenanceWorkerImpl extends PeopleImpl implements MaintenanceWorker {
	/**
	 * The cached value of the '{@link #getUser() <em>User</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUser()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch user;

	/**
	 * The default value of the '{@link #getEmployeeId() <em>Employee Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmployeeId()
	 * @generated
	 * @ordered
	 */
	protected static final String EMPLOYEE_ID_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getEmployeeId() <em>Employee Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmployeeId()
	 * @generated
	 * @ordered
	 */
	protected String employeeId = EMPLOYEE_ID_EDEFAULT;
	/**
	 * The default value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String PHONE_NUMBER_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected String phoneNumber = PHONE_NUMBER_EDEFAULT;
	/**
	 * The default value of the '{@link #getTechnicalSkills() <em>Technical Skills</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTechnicalSkills()
	 * @generated
	 * @ordered
	 */
	protected static final String TECHNICAL_SKILLS_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getTechnicalSkills() <em>Technical Skills</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTechnicalSkills()
	 * @generated
	 * @ordered
	 */
	protected String technicalSkills = TECHNICAL_SKILLS_EDEFAULT;
	/**
	 * The cached value of the '{@link #getWorker() <em>Worker</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWorker()
	 * @generated
	 * @ordered
	 */
	protected People worker;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MaintenanceWorkerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.MAINTENANCE_WORKER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getUser() {
		if (user != null && user.eIsProxy()) {
			InternalEObject oldUser = (InternalEObject) user;
			user = (ElevatorDispatch) eResolveProxy(oldUser);
			if (user != oldUser) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.MAINTENANCE_WORKER__USER, oldUser, user));
			}
		}
		return user;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetUser() {
		return user;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUser(ElevatorDispatch newUser) {
		ElevatorDispatch oldUser = user;
		user = newUser;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.MAINTENANCE_WORKER__USER,
					oldUser, user));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEmployeeId(String newEmployeeId) {
		String oldEmployeeId = employeeId;
		employeeId = newEmployeeId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.MAINTENANCE_WORKER__EMPLOYEE_ID,
					oldEmployeeId, employeeId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhoneNumber(String newPhoneNumber) {
		String oldPhoneNumber = phoneNumber;
		phoneNumber = newPhoneNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.MAINTENANCE_WORKER__PHONE_NUMBER, oldPhoneNumber, phoneNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTechnicalSkills() {
		return technicalSkills;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTechnicalSkills(String newTechnicalSkills) {
		String oldTechnicalSkills = technicalSkills;
		technicalSkills = newTechnicalSkills;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.MAINTENANCE_WORKER__TECHNICAL_SKILLS, oldTechnicalSkills, technicalSkills));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public People getWorker() {
		if (worker != null && worker.eIsProxy()) {
			InternalEObject oldWorker = (InternalEObject) worker;
			worker = (People) eResolveProxy(oldWorker);
			if (worker != oldWorker) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.MAINTENANCE_WORKER__WORKER, oldWorker, worker));
			}
		}
		return worker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public People basicGetWorker() {
		return worker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWorker(People newWorker) {
		People oldWorker = worker;
		worker = newWorker;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.MAINTENANCE_WORKER__WORKER,
					oldWorker, worker));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.MAINTENANCE_WORKER__USER:
			if (resolve)
				return getUser();
			return basicGetUser();
		case ElevatorsystemPackage.MAINTENANCE_WORKER__EMPLOYEE_ID:
			return getEmployeeId();
		case ElevatorsystemPackage.MAINTENANCE_WORKER__PHONE_NUMBER:
			return getPhoneNumber();
		case ElevatorsystemPackage.MAINTENANCE_WORKER__TECHNICAL_SKILLS:
			return getTechnicalSkills();
		case ElevatorsystemPackage.MAINTENANCE_WORKER__WORKER:
			if (resolve)
				return getWorker();
			return basicGetWorker();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.MAINTENANCE_WORKER__USER:
			setUser((ElevatorDispatch) newValue);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__EMPLOYEE_ID:
			setEmployeeId((String) newValue);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__PHONE_NUMBER:
			setPhoneNumber((String) newValue);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__TECHNICAL_SKILLS:
			setTechnicalSkills((String) newValue);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__WORKER:
			setWorker((People) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.MAINTENANCE_WORKER__USER:
			setUser((ElevatorDispatch) null);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__EMPLOYEE_ID:
			setEmployeeId(EMPLOYEE_ID_EDEFAULT);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__PHONE_NUMBER:
			setPhoneNumber(PHONE_NUMBER_EDEFAULT);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__TECHNICAL_SKILLS:
			setTechnicalSkills(TECHNICAL_SKILLS_EDEFAULT);
			return;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__WORKER:
			setWorker((People) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.MAINTENANCE_WORKER__USER:
			return user != null;
		case ElevatorsystemPackage.MAINTENANCE_WORKER__EMPLOYEE_ID:
			return EMPLOYEE_ID_EDEFAULT == null ? employeeId != null : !EMPLOYEE_ID_EDEFAULT.equals(employeeId);
		case ElevatorsystemPackage.MAINTENANCE_WORKER__PHONE_NUMBER:
			return PHONE_NUMBER_EDEFAULT == null ? phoneNumber != null : !PHONE_NUMBER_EDEFAULT.equals(phoneNumber);
		case ElevatorsystemPackage.MAINTENANCE_WORKER__TECHNICAL_SKILLS:
			return TECHNICAL_SKILLS_EDEFAULT == null ? technicalSkills != null
					: !TECHNICAL_SKILLS_EDEFAULT.equals(technicalSkills);
		case ElevatorsystemPackage.MAINTENANCE_WORKER__WORKER:
			return worker != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (employeeId: ");
		result.append(employeeId);
		result.append(", phoneNumber: ");
		result.append(phoneNumber);
		result.append(", technicalSkills: ");
		result.append(technicalSkills);
		result.append(')');
		return result.toString();
	}

} //MaintenanceWorkerImpl
