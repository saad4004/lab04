/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;
import elevatorsystem.metamodel.elevatorsystem.People;
import elevatorsystem.metamodel.elevatorsystem.Tenant;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tenant</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl#getUser <em>User</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl#getUnitNumber <em>Unit Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl#getLivesIn <em>Lives In</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TenantImpl extends PeopleImpl implements Tenant {
	/**
	 * The cached value of the '{@link #getUser() <em>User</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUser()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch user;

	/**
	 * The default value of the '{@link #getUnitNumber() <em>Unit Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUnitNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String UNIT_NUMBER_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getUnitNumber() <em>Unit Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUnitNumber()
	 * @generated
	 * @ordered
	 */
	protected String unitNumber = UNIT_NUMBER_EDEFAULT;
	/**
	 * The default value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String PHONE_NUMBER_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected String phoneNumber = PHONE_NUMBER_EDEFAULT;
	/**
	 * The cached value of the '{@link #getLivesIn() <em>Lives In</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLivesIn()
	 * @generated
	 * @ordered
	 */
	protected People livesIn;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TenantImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.TENANT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getUser() {
		if (user != null && user.eIsProxy()) {
			InternalEObject oldUser = (InternalEObject) user;
			user = (ElevatorDispatch) eResolveProxy(oldUser);
			if (user != oldUser) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ElevatorsystemPackage.TENANT__USER,
							oldUser, user));
			}
		}
		return user;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetUser() {
		return user;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUser(ElevatorDispatch newUser) {
		ElevatorDispatch oldUser = user;
		user = newUser;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.TENANT__USER, oldUser, user));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUnitNumber() {
		return unitNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUnitNumber(String newUnitNumber) {
		String oldUnitNumber = unitNumber;
		unitNumber = newUnitNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.TENANT__UNIT_NUMBER,
					oldUnitNumber, unitNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhoneNumber(String newPhoneNumber) {
		String oldPhoneNumber = phoneNumber;
		phoneNumber = newPhoneNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.TENANT__PHONE_NUMBER,
					oldPhoneNumber, phoneNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public People getLivesIn() {
		if (livesIn != null && livesIn.eIsProxy()) {
			InternalEObject oldLivesIn = (InternalEObject) livesIn;
			livesIn = (People) eResolveProxy(oldLivesIn);
			if (livesIn != oldLivesIn) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ElevatorsystemPackage.TENANT__LIVES_IN,
							oldLivesIn, livesIn));
			}
		}
		return livesIn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public People basicGetLivesIn() {
		return livesIn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLivesIn(People newLivesIn) {
		People oldLivesIn = livesIn;
		livesIn = newLivesIn;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.TENANT__LIVES_IN, oldLivesIn,
					livesIn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.TENANT__USER:
			if (resolve)
				return getUser();
			return basicGetUser();
		case ElevatorsystemPackage.TENANT__UNIT_NUMBER:
			return getUnitNumber();
		case ElevatorsystemPackage.TENANT__PHONE_NUMBER:
			return getPhoneNumber();
		case ElevatorsystemPackage.TENANT__LIVES_IN:
			if (resolve)
				return getLivesIn();
			return basicGetLivesIn();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.TENANT__USER:
			setUser((ElevatorDispatch) newValue);
			return;
		case ElevatorsystemPackage.TENANT__UNIT_NUMBER:
			setUnitNumber((String) newValue);
			return;
		case ElevatorsystemPackage.TENANT__PHONE_NUMBER:
			setPhoneNumber((String) newValue);
			return;
		case ElevatorsystemPackage.TENANT__LIVES_IN:
			setLivesIn((People) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.TENANT__USER:
			setUser((ElevatorDispatch) null);
			return;
		case ElevatorsystemPackage.TENANT__UNIT_NUMBER:
			setUnitNumber(UNIT_NUMBER_EDEFAULT);
			return;
		case ElevatorsystemPackage.TENANT__PHONE_NUMBER:
			setPhoneNumber(PHONE_NUMBER_EDEFAULT);
			return;
		case ElevatorsystemPackage.TENANT__LIVES_IN:
			setLivesIn((People) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.TENANT__USER:
			return user != null;
		case ElevatorsystemPackage.TENANT__UNIT_NUMBER:
			return UNIT_NUMBER_EDEFAULT == null ? unitNumber != null : !UNIT_NUMBER_EDEFAULT.equals(unitNumber);
		case ElevatorsystemPackage.TENANT__PHONE_NUMBER:
			return PHONE_NUMBER_EDEFAULT == null ? phoneNumber != null : !PHONE_NUMBER_EDEFAULT.equals(phoneNumber);
		case ElevatorsystemPackage.TENANT__LIVES_IN:
			return livesIn != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (unitNumber: ");
		result.append(unitNumber);
		result.append(", phoneNumber: ");
		result.append(phoneNumber);
		result.append(')');
		return result.toString();
	}

} //TenantImpl
