/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.Elevator;
import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;
import elevatorsystem.metamodel.elevatorsystem.Esmodel;
import elevatorsystem.metamodel.elevatorsystem.People;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Esmodel</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.EsmodelImpl#getElevatordispatch <em>Elevatordispatch</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.EsmodelImpl#getPeople <em>People</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.EsmodelImpl#getElevator <em>Elevator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EsmodelImpl extends MinimalEObjectImpl.Container implements Esmodel {
	/**
	 * The cached value of the '{@link #getElevatordispatch() <em>Elevatordispatch</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElevatordispatch()
	 * @generated
	 * @ordered
	 */
	protected EList<ElevatorDispatch> elevatordispatch;

	/**
	 * The cached value of the '{@link #getPeople() <em>People</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPeople()
	 * @generated
	 * @ordered
	 */
	protected EList<People> people;

	/**
	 * The cached value of the '{@link #getElevator() <em>Elevator</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElevator()
	 * @generated
	 * @ordered
	 */
	protected EList<Elevator> elevator;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EsmodelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.ESMODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ElevatorDispatch> getElevatordispatch() {
		if (elevatordispatch == null) {
			elevatordispatch = new EObjectContainmentEList<ElevatorDispatch>(ElevatorDispatch.class, this,
					ElevatorsystemPackage.ESMODEL__ELEVATORDISPATCH);
		}
		return elevatordispatch;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<People> getPeople() {
		if (people == null) {
			people = new EObjectContainmentEList<People>(People.class, this, ElevatorsystemPackage.ESMODEL__PEOPLE);
		}
		return people;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Elevator> getElevator() {
		if (elevator == null) {
			elevator = new EObjectContainmentEList<Elevator>(Elevator.class, this,
					ElevatorsystemPackage.ESMODEL__ELEVATOR);
		}
		return elevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ElevatorsystemPackage.ESMODEL__ELEVATORDISPATCH:
			return ((InternalEList<?>) getElevatordispatch()).basicRemove(otherEnd, msgs);
		case ElevatorsystemPackage.ESMODEL__PEOPLE:
			return ((InternalEList<?>) getPeople()).basicRemove(otherEnd, msgs);
		case ElevatorsystemPackage.ESMODEL__ELEVATOR:
			return ((InternalEList<?>) getElevator()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.ESMODEL__ELEVATORDISPATCH:
			return getElevatordispatch();
		case ElevatorsystemPackage.ESMODEL__PEOPLE:
			return getPeople();
		case ElevatorsystemPackage.ESMODEL__ELEVATOR:
			return getElevator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.ESMODEL__ELEVATORDISPATCH:
			getElevatordispatch().clear();
			getElevatordispatch().addAll((Collection<? extends ElevatorDispatch>) newValue);
			return;
		case ElevatorsystemPackage.ESMODEL__PEOPLE:
			getPeople().clear();
			getPeople().addAll((Collection<? extends People>) newValue);
			return;
		case ElevatorsystemPackage.ESMODEL__ELEVATOR:
			getElevator().clear();
			getElevator().addAll((Collection<? extends Elevator>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ESMODEL__ELEVATORDISPATCH:
			getElevatordispatch().clear();
			return;
		case ElevatorsystemPackage.ESMODEL__PEOPLE:
			getPeople().clear();
			return;
		case ElevatorsystemPackage.ESMODEL__ELEVATOR:
			getElevator().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ESMODEL__ELEVATORDISPATCH:
			return elevatordispatch != null && !elevatordispatch.isEmpty();
		case ElevatorsystemPackage.ESMODEL__PEOPLE:
			return people != null && !people.isEmpty();
		case ElevatorsystemPackage.ESMODEL__ELEVATOR:
			return elevator != null && !elevator.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //EsmodelImpl
