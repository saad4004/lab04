/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage
 * @generated
 */
public interface ElevatorsystemFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ElevatorsystemFactory eINSTANCE = elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Building Manager</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Building Manager</em>'.
	 * @generated
	 */
	BuildingManager createBuildingManager();

	/**
	 * Returns a new object of class '<em>Elevator</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Elevator</em>'.
	 * @generated
	 */
	Elevator createElevator();

	/**
	 * Returns a new object of class '<em>Elevator Monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Elevator Monitoring</em>'.
	 * @generated
	 */
	ElevatorMonitoring createElevatorMonitoring();

	/**
	 * Returns a new object of class '<em>Maintenance Worker</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Maintenance Worker</em>'.
	 * @generated
	 */
	MaintenanceWorker createMaintenanceWorker();

	/**
	 * Returns a new object of class '<em>Tenant</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Tenant</em>'.
	 * @generated
	 */
	Tenant createTenant();

	/**
	 * Returns a new object of class '<em>Deliver Person</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Deliver Person</em>'.
	 * @generated
	 */
	DeliverPerson createDeliverPerson();

	/**
	 * Returns a new object of class '<em>Elevator Controls</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Elevator Controls</em>'.
	 * @generated
	 */
	ElevatorControls createElevatorControls();

	/**
	 * Returns a new object of class '<em>Elevator Dispatch</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Elevator Dispatch</em>'.
	 * @generated
	 */
	ElevatorDispatch createElevatorDispatch();

	/**
	 * Returns a new object of class '<em>Esmodel</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Esmodel</em>'.
	 * @generated
	 */
	Esmodel createEsmodel();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ElevatorsystemPackage getElevatorsystemPackage();

} //ElevatorsystemFactory
