/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Model</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getModel()
 * @model
 * @generated
 */
public interface Model extends EObject {
} // Model
