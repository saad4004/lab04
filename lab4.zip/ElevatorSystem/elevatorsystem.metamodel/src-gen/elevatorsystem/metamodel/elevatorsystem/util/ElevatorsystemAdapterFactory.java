/**
 */
package elevatorsystem.metamodel.elevatorsystem.util;

import elevatorsystem.metamodel.elevatorsystem.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage
 * @generated
 */
public class ElevatorsystemAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ElevatorsystemPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorsystemAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ElevatorsystemPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevatorsystemSwitch<Adapter> modelSwitch = new ElevatorsystemSwitch<Adapter>() {
		@Override
		public Adapter caseBuildingManager(BuildingManager object) {
			return createBuildingManagerAdapter();
		}

		@Override
		public Adapter caseElevator(Elevator object) {
			return createElevatorAdapter();
		}

		@Override
		public Adapter caseElevatorMonitoring(ElevatorMonitoring object) {
			return createElevatorMonitoringAdapter();
		}

		@Override
		public Adapter caseMaintenanceWorker(MaintenanceWorker object) {
			return createMaintenanceWorkerAdapter();
		}

		@Override
		public Adapter caseTenant(Tenant object) {
			return createTenantAdapter();
		}

		@Override
		public Adapter caseDeliverPerson(DeliverPerson object) {
			return createDeliverPersonAdapter();
		}

		@Override
		public Adapter caseElevatorControls(ElevatorControls object) {
			return createElevatorControlsAdapter();
		}

		@Override
		public Adapter caseElevatorDispatch(ElevatorDispatch object) {
			return createElevatorDispatchAdapter();
		}

		@Override
		public Adapter casePeople(People object) {
			return createPeopleAdapter();
		}

		@Override
		public Adapter caseEsmodel(Esmodel object) {
			return createEsmodelAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager <em>Building Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager
	 * @generated
	 */
	public Adapter createBuildingManagerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.Elevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.Elevator
	 * @generated
	 */
	public Adapter createElevatorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring <em>Elevator Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring
	 * @generated
	 */
	public Adapter createElevatorMonitoringAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker <em>Maintenance Worker</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker
	 * @generated
	 */
	public Adapter createMaintenanceWorkerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.Tenant <em>Tenant</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant
	 * @generated
	 */
	public Adapter createTenantAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson <em>Deliver Person</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson
	 * @generated
	 */
	public Adapter createDeliverPersonAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls <em>Elevator Controls</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls
	 * @generated
	 */
	public Adapter createElevatorControlsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch <em>Elevator Dispatch</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch
	 * @generated
	 */
	public Adapter createElevatorDispatchAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.People <em>People</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.People
	 * @generated
	 */
	public Adapter createPeopleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link elevatorsystem.metamodel.elevatorsystem.Esmodel <em>Esmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see elevatorsystem.metamodel.elevatorsystem.Esmodel
	 * @generated
	 */
	public Adapter createEsmodelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //ElevatorsystemAdapterFactory
